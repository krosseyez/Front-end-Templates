const observer = new IntersectionObserver((entries)=>{
    entries.foreach((entry)=>{
        console.log(entry)
        if (entry.isIntersecting){
            entry.target.classlist.add('show');
        }else{
            entry.target.classlist.remove('show');
        }
    });
});


const hiddenElements = document.querySelectorAll('.hidden');
hiddenElements.foreach((el)=>observer.observe(el));